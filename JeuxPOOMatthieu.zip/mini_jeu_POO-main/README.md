# mini_jeu_POO

Hello, everyone!

We have created a program in ruby (POO) that acts as a video game centered alone against bots. This video game is turn based. You will incarnate your hero who will have for advantage 100 points of life and a weapon. Several choices will be offered to you at each turn, regain life, find a better weapon or attack the enemies. If you kill all the enemies you win the game, otherwise you lose.

It's up to you to play!

Here you will find 3 different applications, more and less deep according to the given instructions.

We made this work has several, Valentin D. Romuald P. Quentin M. Justin M. Lucas.D
Thanks to all of you.
